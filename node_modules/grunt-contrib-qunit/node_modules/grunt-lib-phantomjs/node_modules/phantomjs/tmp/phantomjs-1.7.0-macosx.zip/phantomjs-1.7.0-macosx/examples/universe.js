// This is to be used by module.js example.

exports.answer = 42;

exports.start = function () {
    console.log('Starting the universe....');
}

